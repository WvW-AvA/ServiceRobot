1.open: behave success, but isopen not change.
2.putin: behave success, but inside not change.
3.takeout:same as behind.